/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module bytebank {
}
