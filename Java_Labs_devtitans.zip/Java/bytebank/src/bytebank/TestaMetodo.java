package bytebank;

public class TestaMetodo {
	public static void main(String[] args) {
		Conta contaDoAdrielson = new Conta();
		contaDoAdrielson.saldo = 100;
		contaDoAdrielson.deposita(50);
		System.out.println("O saldo da Conta do Adrielson é " + contaDoAdrielson.saldo);
		boolean conseguiuRetirar = contaDoAdrielson.saca(20);
		System.out.println("O novo saldo da Conta do Adrielson é " + contaDoAdrielson.saldo);
		System.out.println(conseguiuRetirar);
		
		Conta contaDaShir = new Conta();
		contaDaShir.deposita(1000);
		System.out.println("O saldo da Conta da Shir é " + contaDaShir.saldo);
		contaDaShir.transfere(300, contaDoAdrielson);
		System.out.println("O novo saldo da Conta da Shir é " + contaDaShir.saldo);
		System.out.println("O novo saldo da Conta do Adrielson é " + contaDoAdrielson.saldo);
	}

}
