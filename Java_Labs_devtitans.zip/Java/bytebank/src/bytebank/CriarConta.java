package bytebank;

public class CriarConta {
	public static void main(String[] args) {
		Conta firstConta = new Conta();
		firstConta.saldo = 200;	
		firstConta.saldo += 100;
		System.out.println(firstConta.saldo);
		
		Conta secondConta = new Conta();
		secondConta.saldo = 50;
		
		System.out.println("Primeira Conta tem: " + firstConta.saldo);
		System.out.println("Segunda Conta tem: " + secondConta.saldo);
		
		System.out.println("Agencia primeira Conta: " + firstConta.agencia);
		System.out.println("Agencia segunda Conta: " + secondConta.agencia);
		
		secondConta.agencia = 146;
		
		System.out.println("Agora a segunda conta está na agencia " + secondConta.agencia);
	}

}
