package sintaxevariavelefluxo;

public class TestaValores {
	
	public static void main(String[] args) {
		int primeiro = 5;
		int segundo = 7;
		System.out.println(segundo);
		
	}

}
