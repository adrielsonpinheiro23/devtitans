package sintaxevariavelefluxo;

public class TestaLacos {
	public static void main(String[] args) {
		for(int mult = 1; mult <= 10; mult++) {
			System.out.println("Tabuada do " + mult);
			for (int contador = 0; contador <= 10; contador++) {
				
			System.out.println(mult + " x " + contador + " = " + mult * contador);
		  }
			System.out.println();			
		}
	}

}
