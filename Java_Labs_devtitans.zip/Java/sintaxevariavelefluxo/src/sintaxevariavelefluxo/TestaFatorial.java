package sintaxevariavelefluxo;

public class TestaFatorial {
	public static void main(String[] args) {
		
		int numero = 5;
		long fatorial = 1;		
		for (int i = 1; i <= numero; i++) {
			fatorial *= i;			
		}
//		System.out.println("O Fatorial de " + numero + " é " + fatorial);
		System.out.println(numero + "!" + " é igual a " + fatorial);
	}
}
