package sintaxevariavelefluxo;

public class TestaPontoFlutuante {
	
	public static void main(String[] args) {
		double salario;
		salario = 1250.75;
		System.out.println("Meu salário é " + salario);
	}

}
