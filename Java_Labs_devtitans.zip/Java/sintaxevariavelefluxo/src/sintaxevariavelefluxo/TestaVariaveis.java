package sintaxevariavelefluxo;

public class TestaVariaveis {
	
	public static void main(String[] args) {
		System.out.println("Novo teste");
		
		int idade;
		idade = 32;
		System.out.println(idade);
		
		idade = idade + 10;
		System.out.println("Nova idade 10 anos depois " + idade);
	}

}
