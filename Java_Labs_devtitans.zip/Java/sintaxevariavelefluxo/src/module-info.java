/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module sintaxevariavelefluxo {
}