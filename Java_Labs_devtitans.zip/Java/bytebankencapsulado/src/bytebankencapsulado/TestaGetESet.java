package bytebankencapsulado;

public class TestaGetESet {
	public static void main(String[] args) {
		Conta conta = new Conta(1337, 24226);
		conta.setNumero(1337);
		System.out.println(conta.getNumero());
		
		Cliente adrielson = new Cliente();
		//conta.titular = adrielson;
		conta.setTitular(adrielson);
		adrielson.setNome("Adrielson Antonio");
		adrielson.setCpf("000.994.112-61");
		System.out.println("Nome: " + adrielson.getNome() + "\nCPF:" + adrielson.getCpf());
		System.out.println("Nome pela referencia: " + conta.getTitular().getNome() + "\nCPF por referência:" + conta.getTitular().getCpf());
		
		conta.setTitular(adrielson);
		
		conta.getTitular().setProfissao("Programador");
		Cliente titularDaConta = conta.getTitular();
		titularDaConta.setProfissao("Programador");
		
		System.out.println(titularDaConta);
		System.out.println(adrielson);
		System.out.println(conta.getTitular());
	}

}
