package bytebankencapsulado;

public class TestaValores {
	public static void main(String[] args) {
		Conta contaNova = new Conta(1337, 24226);
		contaNova.setAgencia(-50);
		contaNova.setNumero(-330);
		
		System.out.println(contaNova.getAgencia());
		
		Conta contaNova2 = new Conta(1338, 24227);
		System.out.println(contaNova2.getAgencia());
		
		Conta contaNova3 = new Conta(1338, 24227);
		System.out.println(contaNova3.getAgencia());
		
		System.out.println(contaNova.getTotal());
	}
	
	

}
