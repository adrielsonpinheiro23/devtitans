/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module bytebankencapsulado {
}