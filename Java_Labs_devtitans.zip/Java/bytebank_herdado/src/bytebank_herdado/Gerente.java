package bytebank_herdado;

public class Gerente extends Funcionario {
	
	private int senha;
	
//	public Funcionario() {
//		
//	}
	
	public void setSenha(int senha) {
		this.senha = senha;
	}
		
	
	public boolean autentica(int senha) {
		if (this.senha == senha) {
			return true;
		} else {
			return false;
		}
		
	}	
	
	public double getBonificacao() {
		System.out.println("Chamando metodo de bonificação do gerente");
		return super.getBonificacao() + super.getSalario();
	}

}
