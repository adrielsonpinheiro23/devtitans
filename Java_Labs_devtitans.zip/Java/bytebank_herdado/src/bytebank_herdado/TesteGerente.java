package bytebank_herdado;

public class TesteGerente {

	public static void main(String[] args) {
		Gerente g1 = new Gerente();
		g1.setNome("Marco Gerente");
		g1.setCPF("000.000.000.00");
		g1.setSalario(2500.90);
		g1.setSenha(252524);
//		g1.setTipo(1);		
		
		boolean autenticou = g1.autentica(252524);

		if (autenticou) {
			System.out.println("Bem-Vindo");
		} else {
			System.out.println("Senha incorreta");
		}

		System.out.println("Nome: " + g1.getNome());
		System.out.println("CPF: " + g1.getCPF());
		System.out.println("Salario: " + g1.getSalario());
		
		System.out.println("Bônus de: " + g1.getBonificacao());
		
		
		Funcionario f1 = new Funcionario();
		f1.setNome("Marco Funcionario");
		f1.setCPF("000.000.000-61");
		f1.setSalario(1200.45);
		
		System.out.println("Nome: " + f1.getNome());
		System.out.println("CPF: " + f1.getCPF());
		System.out.println("Salario: " + f1.getSalario());
		
		System.out.println("Bônus de: " + f1.getBonificacao());
		
	}

}
