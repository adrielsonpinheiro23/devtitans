package bytebank_herdado;

public class Teste {
	public static void main(String[] args) {
		Funcionarios f1 = new Funcionarios();
		f1.setTipo(0);
		f1.setSalario(3000.0);
		System.out.println(f1.getTipo());
		System.out.println(f1.getBonificacao());
		
		
		Funcionarios f2 = new Funcionarios();
		f2.setTipo(1);
		f2.setSalario(5000.0);
		System.out.println(f2.getTipo());
		System.out.println(f2.getBonificacao());
		
		Funcionarios f3 = new Funcionarios();
		f3.setTipo(2);
		f3.setSalario(8000.0);
		System.out.println(f3.getTipo());
		System.out.println(f3.getBonificacao());
	}

}
