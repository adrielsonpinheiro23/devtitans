package bytebank_herdado;

public class TestaReferencias {
	public static void main(String[] args) {
		Funcionario g1 = new Gerente();
		g1.setNome("Roberto");
		g1.setSalario(8000.00);
		String nome = g1.getNome();
			
		
		Funcionario f1 = new Funcionario();
		f1.setNome("Thiago Loretto");
		f1.setSalario(2000.00);
		
		
		Funcionario ev = new EditorVideo();
		ev.setNome("Thiago Freitas");
		ev.setSalario(2800.00);
		
		ControleBonificacao controle = new ControleBonificacao();
		
		controle.registra(g1);
			
		System.out.println("Nome do gerente: " + nome);
		System.out.println("Bonificação: " + controle.getSoma());
		
		controle.registra(f1);
		
		System.out.println("Nome do funcionário: " + f1.getNome());
		System.out.println("Bonificação: " + controle.getSoma());
		
		controle.registra(ev);
		
		System.out.println("Nome do Editor de Video: " + ev.getNome());
		System.out.println("Bonificação: " + controle.getSoma());
		
	}

}
