package bytebank_herdado;

public class TesteFuncionario {

	public static void main(String[] args) {
		Funcionario nico = new Funcionario();
		nico.setNome("Nico Steppat");
		nico.setCPF("956589854-48");
		nico.setSalario(2590.80);
		
		System.out.println("Funcionário: " + nico.getNome());
		System.out.println("Bonificação: " + nico.getBonificacao());

	}

}
