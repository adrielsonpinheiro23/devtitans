package br.edu.ufam.icomp.lab_excecoes;

public class Caminho {
	
	private Coordenada[] caminho;
	private int tamanho;
	
	public Caminho (int maxTam) {		
		this.tamanho = 0;		
		this.caminho = new Coordenada[maxTam];
	}
	
	public int tamanho() {
		return tamanho;
	}
		
	public void addCoordenada(Coordenada coordenada) throws TamanhoMaximoExcedidoException, DistanciaEntrePontosExcedidaException {
		caminho[tamanho] = coordenada;
		tamanho+=1; 
		if (tamanho > this.caminho.length) throw new TamanhoMaximoExcedidoException();
		if (tamanho != 0 && coordenada.distancia(this.caminho[tamanho-1]) > 15) throw new DistanciaEntrePontosExcedidaException();
		 		 
	}
	
	public void reset() {
		caminho[tamanho] = null;
	}

	public String toString () {
		String message = "Dados do caminho:\n" +
				"  - Quantidade de pontos: " + this.tamanho + "\n" +
				"  - Pontos:\n";
		
		for (int i = 0; i < tamanho; i++) {
			message += ("	-> " + caminho[i] + "\n");
			
		}
		
		return  message;	 
		
	}		

}
