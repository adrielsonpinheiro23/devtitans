package br.edu.ufam.icomp.lab_excecoes;

public class Coordenada{
	
	private int posX;
	private int posY;
	private int digito;
	
	public Coordenada(int posX, int posY, int digito) throws CoordenadaNegativaException, CoordenadaForaDosLimitesException, DigitoInvalidoException {
		this.posX = posX;
		this.posY = posY;		
		this.digito = digito;
		
		if (this.posX < 0 || this.posY < 0) throw new CoordenadaNegativaException();
		
		if (this.posX < 0 || this.posX > 30000 || this.posY < 0 || this.posY > 30000) throw new CoordenadaForaDosLimitesException(); 
		
		if (((this.posX + this.posY) %10 != this.digito) ||(this.digito < 0) || (this.digito > 9)) throw new DigitoInvalidoException();
		
		
	}
	
	public int getPosX() {	
		return posX;
	}

	public int getPosY() {	
		return posY;
	}
	
	public double distancia(Coordenada coordenada) {
		double dx = this.posX - coordenada.posX;
		double dy = this.posY - coordenada.posY;
		return Math.sqrt(dx * dx + dy * dy);
		
	}
	
	public String toString() {
		return getPosX() + "," + getPosY();
	}
	
}
