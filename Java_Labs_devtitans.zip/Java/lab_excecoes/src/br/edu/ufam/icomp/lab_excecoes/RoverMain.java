package br.edu.ufam.icomp.lab_excecoes;

public class RoverMain {

	public static void main(String[] args) throws TamanhoMaximoExcedidoException, DistanciaEntrePontosExcedidaException {
		Caminho c = new Caminho(6);
		
		Coordenada c1;
		Coordenada c2;
		Coordenada c3;
		Coordenada c4;
		Coordenada c5;
		Coordenada c6;

		
		try {
			c1 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c1);
			
			c2 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c2);
			
			c3 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c3);
			
			c4 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c4);
			
			c5 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c5);
			
			c6 = new Coordenada(23, 41, 4);
			
			c.addCoordenada(c6);
			
			
		}
		catch (CoordenadaNegativaException e)  {
			System.out.println(e.getMessage());
			return;
		}
		catch (CoordenadaForaDosLimitesException e) {
			System.out.println(e.getMessage());
			return;

		}
		catch (DigitoInvalidoException e) {
			System.out.println(e.getMessage());
			return;

		}
		catch (TamanhoMaximoExcedidoException e) {
			System.out.println(e.getMessage());
			return;

		}
		catch(DistanciaEntrePontosExcedidaException e) {
			System.out.println(e.getMessage());
			return;

		}
		
		System.out.println(c.toString());
		
	}

}
