package br.com.bytebank_herdado_conta.teste.util;

public class TesteWrappers {

	public static void main(String[] args) {

		Integer idadeRef = Integer.valueOf(32); //autoboxing
		System.out.println(idadeRef.intValue()); //unboxing	
		
		Double dRef = Double.valueOf(32); //autoboxing
		System.out.println(dRef.doubleValue()); //unboxing	
	}

}
