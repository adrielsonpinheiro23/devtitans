package br.com.bytebank_herdado_conta.teste.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import br.com.bytebank_herdado_conta.modelo.Conta;
import br.com.bytebank_herdado_conta.modelo.ContaCorrente;

public class TesteArrayListEquals {

	public static void main(String[] args) {

		List<Conta> lista = new ArrayList<Conta>();

		Conta cc = new ContaCorrente(22, 11);
		lista.add(cc);

		Conta cc2 = new ContaCorrente(22, 22);
		lista.add(cc2);
		
		System.out.println("Tamanho: " + lista.size());
		Conta ref = lista.get(0);
		System.out.println("Primeiro item: " + ref.getNumero());
		
		Conta cc3 = new ContaCorrente(22, 22);
		boolean existe = lista.contains(cc3);
		
		for(Conta conta: lista) {
			if(conta.equals(cc3)) {
				System.out.println("Ja tenho essa conta!");
			}
		}

		for (Conta conta : lista) {
			System.out.println(conta);
		}

	}
}
