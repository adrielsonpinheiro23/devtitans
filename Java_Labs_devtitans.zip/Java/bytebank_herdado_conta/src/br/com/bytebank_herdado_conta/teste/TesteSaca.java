package br.com.bytebank_herdado_conta.teste;

import br.com.bytebank_herdado_conta.modelo.*;

public class TesteSaca {
	public static void main(String[] args) {
		Conta cc = new ContaCorrente(123, 321);
		
		cc.deposita(200.0);
		try {	
			cc.saca(210.0);
		} catch (SaldoInsuficienteException ex) {
			System.out.println("Erro: " + ex.getMessage());
			
		}
		
		System.out.println(cc.getSaldo());
	}

}
