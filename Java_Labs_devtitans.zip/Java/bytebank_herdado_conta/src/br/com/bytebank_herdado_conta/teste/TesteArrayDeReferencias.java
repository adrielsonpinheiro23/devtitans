package br.com.bytebank_herdado_conta.teste;

import br.com.bytebank_herdado_conta.modelo.Conta;
import br.com.bytebank_herdado_conta.modelo.ContaCorrente;
import br.com.bytebank_herdado_conta.modelo.ContaPoupanca;

public class TesteArrayDeReferencias {

	public static void main(String[] args) {
		
		Object[] referencias = new Conta[5];
		
		ContaCorrente cc1 = new ContaCorrente(22, 11);
		referencias[0] = cc1;
		
		ContaPoupanca cp1 = new ContaPoupanca(22, 25);
		referencias[1] = cp1;
		
		System.out.println("Imprimindo do objeto " + cc1.getNumero());
		
		System.out.println("Imprimindo do Array " + ((Conta) referencias[1]).getNumero());
		
		ContaPoupanca ref = (ContaPoupanca) referencias[1]; // Type cast
				
		System.out.println("Imprimindo da referencia " + ref.getNumero());
		
	}

}
