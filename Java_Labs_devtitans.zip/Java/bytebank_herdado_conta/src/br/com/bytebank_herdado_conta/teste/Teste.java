package br.com.bytebank_herdado_conta.teste;

public class Teste {

	public static void main(String[] args) {
		System.out.println();

	}

}
