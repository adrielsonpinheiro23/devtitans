package br.com.bytebank_herdado_conta.teste;

import br.com.bytebank_herdado_conta.modelo.*;


public class TestaCripto {
	public static void main(String[] args) {
		var cript = Criptografia(15200, 10, 800);
		System.out.println(cript);
	}

	private static Object Criptografia(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}

}
