package br.com.bytebank_herdado_conta.teste;

public class TesteString {
	public static void main(String[] args) {
		
		String nome = "Adrielson"; // Objeto literal
		//String outroNome = new String("Shirlaine");
		
		String mudado = nome.replace("A", "a");		
		String nomeMinusculo = nome.toLowerCase();
		String nomeMaiusculo = nome.toUpperCase();
		
		
		System.out.println(mudado);
		System.out.println(nomeMinusculo);
		System.out.println(nomeMaiusculo);
		
		char a = 'B';
		char b = 'C';
		
		String outra = nome.replace(a, b);
		System.out.println("Teste char " + outra);
		
		char c = nome.charAt(2);
		System.out.println(c);
		
		// Loop com length
		System.out.println("\n");
		for (int i = 0; i < nome.length(); i++) {			
			System.out.println(nome.charAt(i));
		}

		System.out.println("\n\n\n");
		String vazio = " Adrielson Pinheiro";
		String testeDoTrim = vazio.trim();
		System.out.println(vazio);
		System.out.println(testeDoTrim);
	}

}
