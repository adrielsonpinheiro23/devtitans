package br.com.bytebank_herdado_conta.teste;

import br.com.bytebank_herdado_conta.modelo.*;

/**
 * Classe para testar as contas
 * 
 * @author a.adrielson
 * @version 0.1
 *
 */

public class TesteContas {
	
	/**
	 * Parametros para inicializar a função
	 * 
	 * @param args
	 * @throws SaldoInsuficienteException
	 */

	//java.lang.String
	public static void main(String[] args) throws SaldoInsuficienteException {
		ContaCorrente cc = new ContaCorrente(2905, 1053108);
		cc.deposita(100);
		
		ContaPoupanca cp = new ContaPoupanca(222, 222);
		cp.deposita(200.0);
		
		cc.transfere(10.0, cp);
		cc.saca(10);
		
		System.out.println("CC: " + cc.getSaldo());
		System.out.println("CP: " + cp.getSaldo());

		
		
	}

}
