package br.com.bytebank_herdado_conta.modelo;

public class TesteArrayDePrimitivos {

	//Array
	public static void main(String[] args) {
		int[] idades = new int[8];
		
		for(int i = 0; i < idades.length; i++) {
			idades[i] = i * i;
		}
		
		for(int i = 0; i < idades.length; i++) {
			System.out.println(idades[i]);
		}
	}

}
