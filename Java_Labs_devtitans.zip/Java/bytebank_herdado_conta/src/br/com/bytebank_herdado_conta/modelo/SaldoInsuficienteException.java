package br.com.bytebank_herdado_conta.modelo;

public class SaldoInsuficienteException extends Exception {
	public SaldoInsuficienteException(String msg) {
		super(msg);
	}

}