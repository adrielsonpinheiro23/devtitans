package br.com.bytebank_herdado_conta.modelo;

public class Cripting {

	public static int Criptografia (long bytes, int verificador, int auxiliar)
	  {
	     long result = bytes + auxiliar;
	     result = result / verificador;
	     return  (int) result;
	  }
	
	public static void main(String[] args) {
		var cript = Criptografia(15200, 10, 800);
		System.out.println(cript);
}
}
