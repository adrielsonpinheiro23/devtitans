package br.com.bytebank_herdado_conta.modelo;

public interface Tributavel {
	
	double getValorImposto(); //public abstract é o padrão pra métodos na Interface
	

}
