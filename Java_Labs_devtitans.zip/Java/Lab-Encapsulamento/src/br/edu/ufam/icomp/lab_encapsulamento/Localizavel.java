package br.edu.ufam.icomp.lab_encapsulamento;

public interface Localizavel {
	
	Posicao getPosicao();
	
	double getErroLocalizacao();

}
