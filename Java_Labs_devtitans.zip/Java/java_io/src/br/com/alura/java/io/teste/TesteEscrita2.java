package br.com.alura.java.io.teste;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TesteEscrita2 {

	public static void main(String[] args) throws IOException {
		
	
		BufferedWriter bw = new BufferedWriter(new FileWriter("Onboarding2.txt"));
		bw.write("FUNCIONOU A ESCRITA DE ARQUIVOS");
		bw.write(System.lineSeparator());
		bw.write(System.lineSeparator());
		bw.write(System.lineSeparator());
		bw.write("\n");
		bw.newLine();
		bw.write("ACABOU O ARQUIVO");
		
		bw.close();

	}

}
