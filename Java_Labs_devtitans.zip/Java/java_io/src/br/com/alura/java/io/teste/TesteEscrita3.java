package br.com.alura.java.io.teste;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

public class TesteEscrita3 {

	public static void main(String[] args) throws IOException {
		
			
		PrintStream ps = new PrintStream("Onboarding2.txt");
//		PrintWriter ps = new PrintWriter("Onboarding2.txt"); // mais alto nivel
		ps.println("FUNCIONOU A ESCRITA DE ARQUIVOS");
		
		PrintStream ps2 = new PrintStream(new File("Onboarding.txt"));
				
		ps.println();
		ps.println();
		ps.println("ACABOU O ARQUIVO");
		ps.println();
		ps.println("ACABOU DE VERDADE ARQUIVO");
		
		ps.close();

	}

}
