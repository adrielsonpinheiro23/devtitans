/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module bytebankcomposto {
}