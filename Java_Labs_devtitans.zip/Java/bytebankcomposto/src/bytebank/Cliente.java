package bytebank;

public class Cliente {
	String nome;
	String cpf;
	String profissao;
	

}
