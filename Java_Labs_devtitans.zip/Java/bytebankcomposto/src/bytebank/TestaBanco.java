package bytebank;

public class TestaBanco {
	public static void main(String[] args) {
		Cliente adrielson = new Cliente();
		adrielson.nome = "Adrielson Pinheiro";
		adrielson.cpf = "000.000.000-61";
		adrielson.profissao = "QA";
		
		Conta contaDoAdrielson = new Conta();
		contaDoAdrielson.deposita(100);
		
		contaDoAdrielson.titular = adrielson;
		System.out.println(contaDoAdrielson.titular.nome);
	}

}
