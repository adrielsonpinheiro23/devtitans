/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module sintaxebasica {
}