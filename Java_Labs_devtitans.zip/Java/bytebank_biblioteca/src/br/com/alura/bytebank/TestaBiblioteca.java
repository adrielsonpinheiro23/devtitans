package br.com.alura.bytebank;

import br.com.bytebank_herdado_conta.modelo.Conta;
import br.com.bytebank_herdado_conta.modelo.ContaCorrente;

public class TestaBiblioteca {
	public static void main(String[] args) {
		
		Conta c = new ContaCorrente(123, 321);

	}

}
