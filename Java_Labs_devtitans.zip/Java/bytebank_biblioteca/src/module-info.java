/**
 * 
 */
/**
 * @author a.adrielson
 *
 */
module bytebank_biblioteca {
	requires bytebank_herdado_conta;
}