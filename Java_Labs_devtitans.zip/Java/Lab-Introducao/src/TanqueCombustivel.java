import java.util.Scanner;

public class TanqueCombustivel {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		float raio = scan.nextFloat();
		float altura = scan.nextFloat();
		int opcao = scan.nextInt();
		
		double volume, volumeCalota, volumeCombustivel;		
		
		
				
		if (opcao == 1) {
			volumeCalota = (Math.PI/3)*Math.pow(altura,2)*(3*raio-altura);
			String result = String.format("%.4f", volumeCalota);
			System.out.println(result);
		}
		
		if (opcao == 2) {
			volumeCalota = (Math.PI/3)*Math.pow(altura,2)*(3*raio-altura);
			volume = 1.33333333333*Math.PI*Math.pow(raio,3);	
			
			volumeCombustivel = (volume - volumeCalota);			
			String result = String.format("%.4f", volumeCombustivel);
			System.out.println(result);
			
		} 
	}

	
}
