import java.util.Scanner;

public class ArteAscii {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);	
				
		int asteriscos = scan.nextInt();
		int asteriscos_linha = asteriscos;
		
		for (int j = 1; j<=asteriscos; j++) {
			
		for(int i = 1;	i<=	asteriscos_linha; i++) {
			
			System.out.print("*");
		}		
		System.out.println();
		asteriscos_linha-=1;
		}
		
		asteriscos_linha+=1;
		for (int j = 1; j<=asteriscos; j++) {
			
			for(int i = 1;	i<=	asteriscos_linha; i++) {
				
				System.out.print("*");
			}		
			System.out.println();
			asteriscos_linha+=1;
			}
			
			}
		

	}


