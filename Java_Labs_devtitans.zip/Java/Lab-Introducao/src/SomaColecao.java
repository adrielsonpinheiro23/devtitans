import java.util.Scanner;

public class SomaColecao {

	public static void main(String[] args) {
			
		int[] num = new int[100];
		int i = 1;
		int soma = 0;
		
		Scanner scan = new Scanner(System.in);
		
		while (num[i-1]!=(-1)) {
		num[i] = scan.nextInt();
		i++;
		}
	
		
		for (i=0; i < num.length; i++) {
			if (num[i]!=-1) {
			soma = soma + num[i];
			}
		}
	System.out.println(soma);

	}
}
