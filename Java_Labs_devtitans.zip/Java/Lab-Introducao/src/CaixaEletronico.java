import java.util.Scanner;

public class CaixaEletronico {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int saque = scan.nextInt();
		int notas50, notas10, notas2;	
		int restanteDas50, restanteDas10;
		restanteDas50 = restanteDas10 = 0;
		notas50 = notas10 = notas2 = 0;
		
		if (saque%2==0 && saque>0)  {
			notas50 = saque / 50;
			restanteDas50 = saque%50;
			notas10 = restanteDas50 / 10;
			restanteDas10 = restanteDas50%10;
			notas2 = restanteDas10 / 2;
			
			
			System.out.println(notas50 + " notas de R$50, " + notas10 + " notas de R$10 e " + notas2 + " notas de R$2");
			
		}
		else {
			System.out.println("Valor Invalido");		
			
		}
		
		
	}

}
