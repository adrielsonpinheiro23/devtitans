import java.util.Scanner;

public class DataExtenso {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String data = scan.next();
		
		String dia = data.substring(0,2);
		String mes = data.substring(2,4);
		String ano = data.substring(4,8);
		
		String mes_extenso = "";
		if (mes.equals("01")) mes_extenso = "janeiro";
		if (mes.equals("02")) mes_extenso = "fevereiro";
		if (mes.equals("03")) mes_extenso = "março";
		if (mes.equals("04")) mes_extenso = "abril";
		if (mes.equals("05")) mes_extenso = "maio";
		if (mes.equals("06")) mes_extenso = "junho";
		if (mes.equals("07")) mes_extenso = "julho";
		if (mes.equals("08")) mes_extenso = "agosto";
		if (mes.equals("09")) mes_extenso = "setembro";
		if (mes.equals("10")) mes_extenso = "outubro";
		if (mes.equals("11")) mes_extenso = "novembro";
		if (mes.equals("12")) mes_extenso = "dezembro";
		
		System.out.println(dia + " de " + mes_extenso + " de " + ano);
	}
	
}
