
public class TheForce {

	public static void main(String[] args) {
		System.out.println("May the Force be with you");

	}

}
