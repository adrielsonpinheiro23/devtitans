package java_pilha;

public class Conta extends Exception { //checked
	
	void deposita() throws MinhaExcecao {
		
		
	}

}
