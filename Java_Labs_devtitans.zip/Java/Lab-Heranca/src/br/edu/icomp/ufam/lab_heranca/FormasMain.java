package br.edu.icomp.ufam.lab_heranca;

public class FormasMain {

	public static void main(String[] args) {
		FormaGeometrica formas[] = new FormaGeometrica[100];
		
		Quadrado qd = new Quadrado(1, 2, 2.5);
		Retangulo rt = new Retangulo(1, 1, 2.1, 2.0);
		Circulo cl = new Circulo(1, 1, 2.2);
		
		formas[0] = qd;
		formas[1] = rt;
		formas[2] = cl;
		
		System.out.println(qd);
		System.out.println(rt);
		System.out.println(cl);
		
	}

}
