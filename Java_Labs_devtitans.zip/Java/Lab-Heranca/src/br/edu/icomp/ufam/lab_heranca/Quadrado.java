package br.edu.icomp.ufam.lab_heranca;

public class Quadrado extends Retangulo {

	public double lado;

	public Quadrado(int posX, int posY, double lado) {
		super(posX, posY, lado, lado);
		this.posX = posX;
		this.posY = posY;
		this.setLado(lado);		
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}

	public String toString() {
		return "Quadrado na posição (" + this.posX + ", " + this.posY + ") com lado de " + this.lado + "cm (área="+ getArea() + "cm2, perímetro="+ getPerimetro() + "cm)" ;
	}
}
