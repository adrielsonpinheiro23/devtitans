
public class CarroMain {

	public static void main(String[] args) {
		Proprietario p1 = new Proprietario("Emmett L. Brown", 552662, 1990);
		
		System.out.println(p1.getDescricao());
		p1.getIdade(1975);
		
		Placa placa1 = new Placa("OAA-7544", 2);
		
		System.out.println(placa1.getDescricao());
		
		Motor motor1 = new Motor(1, 2.85, 130);
		
		System.out.println(motor1.getDescricao());
		
		
		Carro c1 = new Carro("DeLorean", "DMC-12", p1, placa1, motor1);
		
		System.out.println(c1.getDescricao());
	}

}
