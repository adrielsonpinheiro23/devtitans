
public class Placa {

	String placa;
	int tipo;
	
	
	Placa () {
		placa = "";
		tipo = 0;
	}
	
	Placa(String placa, int tipo) {
		this.placa = placa;
		this.tipo = tipo;
	}
	
	public String getTipoString() {
		if (this.tipo == 1) {
			return "Normal"; }
		if (this.tipo == 2) {
			return "Serviço";
		}
		if (this.tipo == 3) {
			return "Oficial";
		}
		if (this.tipo == 4) {
			return "Auto Escola";
		}
		if (this.tipo == 5) {
			return "Prototipo";
		}
		if (this.tipo == 6) {
			return "Colecionador";
		}
		else {
			return "Outros";
		}
	}
	
	public boolean temEstacionamentoLivre() {		
		if (this.tipo == 2 || this.tipo == 3) {
			return true;	
		}
		return false;
	}
	

	public String getDescricao() {
		return "Placa: placa=" + this.placa+ ", tipo=" + getTipoString() + ", estacionamentoLivre=" + temEstacionamentoLivre()+".";
	}
	
}
