import java.util.Calendar;

public class Proprietario {
	
	String nome;
	int cnh;
	int anoNascimento;
	
	Proprietario () {
		nome = "";
		cnh = 0;
		anoNascimento = 0;
			
	}
	
	Proprietario (String nome, int cnh, int anoNascimento) {
		this.nome = nome;
		this.cnh = cnh;
		this.anoNascimento = anoNascimento;
	}
	
	int getIdade(int anoReferencia) {
		int idade;
		//int year = Calendar.getInstance().get(Calendar.YEAR);
		idade = anoReferencia - this.anoNascimento;
		return idade;
	}

	public String getDescricao() {
		return "Proprietario: nome=" + this.nome+ ", cnh=" + this.cnh + ", anoNascimento=" + this.anoNascimento+".";
	}
	

}
